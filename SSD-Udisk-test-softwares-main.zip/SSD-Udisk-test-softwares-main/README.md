SSD测试软件
U盘量产工具和chipgenius检测工具等

截至当前，chIpgenius最新版地址：
https://www.mydigit.cn/forum.php?mod=viewthread&tid=209287
